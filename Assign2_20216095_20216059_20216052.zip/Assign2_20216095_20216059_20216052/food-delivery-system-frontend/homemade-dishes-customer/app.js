// app.js

// Tab switching logic
const tabs = document.querySelectorAll('.tab');
const forms = {
    register: document.getElementById('register-form'),
    login: document.getElementById('login-form'),
    orders: document.getElementById('orders-section'),
    newOrder: document.getElementById('new-order-form'),
};
const confirmationMessage = document.getElementById('confirmation-message');

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        // Remove active from all tabs
        tabs.forEach(t => t.classList.remove('active'));
        // Add active to clicked tab
        tab.classList.add('active');

        // Hide all sections
        Object.values(forms).forEach(f => f.classList.add('hidden'));
        confirmationMessage.classList.add('hidden');

        // Show related section
        if (tab.id === 'tab-register') forms.register.classList.remove('hidden');
        else if (tab.id === 'tab-login') forms.login.classList.remove('hidden');
        else if (tab.id === 'tab-orders') {
            forms.orders.classList.remove('hidden');
            fetchOrders();
        }
        else if (tab.id === 'tab-new-order') {
            forms.newOrder.classList.remove('hidden');
            fetchDishes();
        }
    });
});


const API_BASE_URL = ' http://localhost:8080/UserService/api/auth/register-customer';

// --- Register ---
forms.register.addEventListener('submit', async e => {
    e.preventDefault();

    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;

    try {
        const res = await fetch(`${API_BASE_URL}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({name, email, password}),
        });

        if (!res.ok) {
            const error = await res.json();
            alert('Registration failed: ' + (error.message || 'Unknown error'));
            return;
        }

        alert('Registered successfully! Redirecting to login...');
        window.location.href = 'login.html';
    } catch (err) {
        alert('Error connecting to server: ' + err.message);
    }
});

// --- Login ---
forms.login.addEventListener('submit', async e => {
    e.preventDefault();

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const res = await fetch('http://localhost:8085/auth/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            email: email,
            password: password
          })
        });

        if (!res.ok) {
            const error = await res.json();
            alert('Login failed: ' + (error.message || 'Unknown error'));
            return;
        }

       const token = await res.text();
       console.log(token);

        localStorage.setItem("userEmail", email);
        localStorage.setItem("token", token);

        alert('Login successful! Redirecting to dashboard...');
        window.location.href = 'dashboard.html';
    } catch (err) {
        alert('Error connecting to server: ' + err.message);
    }
});

// --- Fetch dishes from backend ---
async function fetchDishes() {
    try {
        const res = await fetch(`${API_BASE_URL}/dishes`, {
            headers: { 'Authorization': 'Bearer ' + localStorage.getItem('token') }
        });

        if (!res.ok) throw new Error('Failed to fetch dishes');

        const dishesFromBackend = await res.json();
        window.dishes = dishesFromBackend;

        const dishList = document.getElementById('dish-list');
        dishList.innerHTML = '';

        dishesFromBackend.forEach(dish => {
            const dishDiv = document.createElement('div');
            dishDiv.className = 'dish-item card';

            dishDiv.innerHTML = `
              <img src="${dish.imageUrl || 'assets/default-dish.png'}" alt="${dish.name}" class="dish-img"/>
              <div class="dish-info">
                <div class="dish-name">${dish.name}</div>
                <div class="dish-price">EGP ${dish.price}</div>
              </div>
              <input type="number" min="0" value="0" class="dish-amount" data-id="${dish.id}" />
            `;
            dishList.appendChild(dishDiv);
        });

        // Recalculate total price when quantity changes
        dishList.addEventListener('input', () => {
            totalPriceSpan.textContent = calculateTotal();
        });

    } catch (error) {
        alert('Error loading dishes: ' + error.message);
    }
}

// --- Fetch user orders ---
async function fetchOrders() {
    const userId = localStorage.getItem('userId');
    if (!userId) {
        alert('Not logged in');
        return;
    }

    try {
        const res = await fetch(`${API_BASE_URL}/orders/user/${userId}`, {
            headers: {
                Authorization: 'Bearer ' + localStorage.getItem('token')
            }
        });

        if (!res.ok) throw new Error('Failed to fetch orders');

        const orders = await res.json();

        const ordersList = document.getElementById('orders-list');
        if (orders.length === 0) {
            ordersList.innerHTML = '<p>No orders yet.</p>';
            return;
        }

        ordersList.innerHTML = '';
        orders.forEach(order => {
            const orderDiv = document.createElement('div');
            orderDiv.className = 'order-card';

            let dishDetails = order.dishes.map(d => `${d.amount} × ${d.name}`).join(', ');

            orderDiv.innerHTML = `
              <div class="order-header">Order #${order.id} - ${new Date(order.date).toLocaleDateString()}</div>
              <div class="order-details">Items: ${dishDetails}</div>
              <div class="order-details">Status: <strong>${order.status}</strong></div>
            `;

            ordersList.appendChild(orderDiv);
        });

    } catch (error) {
        alert('Error loading orders: ' + error.message);
    }
}

// --- Calculate total price including shipping ---
const locationSelect = document.getElementById('location-select');
const shippingSelect = document.getElementById('shipping-select');
const totalPriceSpan = document.getElementById('total-price');

const shippingFees = {
    Cairo: 20,
    Giza: 25,
    Alexandria: 30,
    Other: 50,
};

function calculateTotal() {
    const amounts = [...document.querySelectorAll('.dish-amount')];
    let dishesTotal = 0;
    amounts.forEach(input => {
        const amount = parseInt(input.value) || 0;
        const dishId = parseInt(input.getAttribute('data-id'));
        const dish = window.dishes.find(d => d.id === dishId);
        if (dish) dishesTotal += amount * dish.price;
    });

    const location = locationSelect.value;
    const shippingFee = shippingFees[location] || 0;

    return dishesTotal + shippingFee;
}

locationSelect.addEventListener('change', () => {
    totalPriceSpan.textContent = calculateTotal();
});

shippingSelect.addEventListener('change', () => {
    totalPriceSpan.textContent = calculateTotal();
});

// --- Place new order ---
forms.newOrder.addEventListener('submit', async e => {
    e.preventDefault();

    const amounts = [...document.querySelectorAll('.dish-amount')];
    const orderedDishes = amounts
        .filter(input => parseInt(input.value) > 0)
        .map(input => {
            const dishId = parseInt(input.getAttribute('data-id'));
            return {
                dishId: dishId,
                amount: parseInt(input.value),
            };
        });

    if (orderedDishes.length === 0) {
        alert('Please select at least one dish with amount > 0');
        return;
    }

    const location = locationSelect.value;
    const shippingCompany = shippingSelect.value;

    if (!location) {
        alert('Please select a shipping location.');
        return;
    }
    if (!shippingCompany) {
        alert('Please select a shipping company.');
        return;
    }

    if (location === 'Other') {
        alert('Sorry, shipping not available for your selected location. Please choose another.');
        return;
    }

    const userId = localStorage.getItem('userId');
    if (!userId) {
        alert('Please login first.');
        return;
    }

    const orderPayload = {
        userId: userId,
        dishes: orderedDishes,
        shippingLocation: location,
        shippingCompany: shippingCompany,
    };

    try {
        const res = await fetch(`${API_BASE_URL}/orders`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: 'Bearer ' + localStorage.getItem('token'),
            },
            body: JSON.stringify(orderPayload),
        });

        if (!res.ok) {
            const err = await res.json();
            alert('Failed to place order: ' + (err.message || 'Unknown error'));
            return;
        }

        confirmationMessage.textContent = 'Order placed successfully! Thank you for your purchase.';
        confirmationMessage.classList.remove('hidden');

        // Clear inputs
        amounts.forEach(input => (input.value = 0));
        locationSelect.value = '';
        shippingSelect.value = '';
        totalPriceSpan.textContent = '0';

        fetchOrders();
    } catch (error) {
        alert('Error placing order: ' + error.message);
    }
});

// Initially show Register form (optional)
// forms.register.classList.remove('hidden');
