const dishList = document.getElementById("dishList");
const soldDishList = document.getElementById("soldDishList");
const dishModal = document.getElementById("dishModal");
const dishForm = document.getElementById("dishForm");
const addDishBtn = document.getElementById("addDishBtn");
const soldModal = document.getElementById("soldModal");
const soldForm = document.getElementById("soldForm");
const addSoldDishBtn = document.getElementById("addSoldDishBtn");

const userEmailSpan = document.getElementById('userEmail');
const logoutBtn = document.getElementById('logoutBtn');
const searchInput = document.getElementById('searchInput');

const dishImageInput = document.getElementById('dishImage');
const dishImagePreview = document.getElementById('dishImagePreview');

let editingDishId = null;

userEmailSpan.textContent = localStorage.getItem('userEmail') || 'seller@example.com';

logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('loggedIn');
    localStorage.removeItem('userEmail');
    window.location.href = 'login.html';
});

// LocalStorage keys
const DISHES_KEY = 'mock_dishes';
const SOLD_DISHES_KEY = 'mock_sold_dishes';

// Helpers to get/set dishes in localStorage
function getLocalDishes() {
    return JSON.parse(localStorage.getItem(DISHES_KEY) || '[]');
}
function saveLocalDishes(dishes) {
    localStorage.setItem(DISHES_KEY, JSON.stringify(dishes));
}

function getLocalSoldDishes() {
    return JSON.parse(localStorage.getItem(SOLD_DISHES_KEY) || '[]');
}
function saveLocalSoldDishes(soldDishes) {
    localStorage.setItem(SOLD_DISHES_KEY, JSON.stringify(soldDishes));
}

// Render dishes from localStorage, filter by name
function renderDishes(filter = '') {
    dishList.innerHTML = '';
    let dishes = getLocalDishes();

    const filtered = dishes.filter(d => d.name.toLowerCase().includes(filter.toLowerCase()));

    if (filtered.length === 0) {
        dishList.innerHTML = `<p id="emptyDishesMsg" style="grid-column:1/-1; text-align:center; padding:2rem; color:#666;">No dishes available. Click "+ Add Dish" to get started.</p>`;
        return;
    }

    filtered.forEach(dish => {
        const card = document.createElement("div");
        card.className = "card";

        const imageHTML = dish.imageBase64
            ? `<img src="${dish.imageBase64}" alt="${dish.name}" style="width: 100%; max-height: 150px; object-fit: cover; border-radius: 8px; margin-bottom: 0.5rem;" />`
            : '';

        card.innerHTML = `
            ${imageHTML}
            <h3>${dish.name}</h3>
            <p class="amount">Amount: ${dish.amount}</p>
            <p class="price">Price: $${dish.price.toFixed(2)}</p>
            <small>Offered Dish</small>
            <div class="card-actions">
              <button class="editBtn">Edit</button>
              <button class="deleteBtn">Delete</button>
            </div>
        `;

        card.querySelector(".editBtn").addEventListener("click", () => {
            editingDishId = dish.id;
            dishForm.elements[0].value = dish.name;
            dishForm.elements[1].value = dish.amount;
            dishForm.elements[2].value = dish.price;

            if (dish.imageBase64) {
                dishImagePreview.src = dish.imageBase64;
                dishImagePreview.style.display = 'block';
            } else {
                dishImagePreview.src = '';
                dishImagePreview.style.display = 'none';
            }

            dishImageInput.value = '';
            document.getElementById('modalTitle').textContent = "Edit Dish";
            dishModal.style.display = "flex";
        });

        card.querySelector(".deleteBtn").addEventListener("click", () => {
            if (confirm(`Delete dish "${dish.name}"?`)) {
                let allDishes = getLocalDishes();
                allDishes = allDishes.filter(d => d.id !== dish.id);
                saveLocalDishes(allDishes);
                renderDishes(searchInput.value);
            }
        });

        dishList.appendChild(card);
    });
}

// Render sold dishes from localStorage
function renderSoldDishes(soldDishList) {
    soldDishList.innerHTML = '';
    const soldDishes = getLocalSoldDishes();

    if (soldDishes.length === 0) {
        soldDishList.innerHTML = `<p id="emptySoldDishesMsg" style="grid-column:1/-1; text-align:center; padding:2rem; color:#666;">No sold dishes to display.</p>`;
        return;
    }

    soldDishes.forEach(dish => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <h3>${dish.dishId}</h3>
            <p>Customer Name: ${dish.customerName}</p>
            <p>Customer Email: ${dish.customerEmail}</p>
            <p>Shipping Company: ${dish.shippingCompany}</p>
            <p>Quantity Sold: ${dish.quantity}</p>
            <p>Total Price $${dish.totalPrice}</p>
            <small>Sold Dish</small>
        `;
        soldDishList.appendChild(card);
    });
}

// Show image preview when image selected
dishImageInput.addEventListener('change', () => {
    const file = dishImageInput.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            dishImagePreview.src = e.target.result;
            dishImagePreview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    } else {
        dishImagePreview.src = '';
        dishImagePreview.style.display = 'none';
    }
});

// Add Dish button
addDishBtn.addEventListener("click", () => {
    editingDishId = null;
    dishForm.reset();
    dishImagePreview.src = '';
    dishImagePreview.style.display = 'none';
    dishImageInput.value = '';
    document.getElementById('modalTitle').textContent = "Add New Dish";
    dishModal.style.display = "flex";
});

// Close dish modal
document.getElementById("closeModal").addEventListener("click", () => {
    dishModal.style.display = "none";
    editingDishId = null;
});


dishForm.addEventListener("submit", e => {
    e.preventDefault();

    const name = dishForm.elements[0].value.trim();
    const stock = parseInt(dishForm.elements[1].value);
    const price = parseFloat(dishForm.elements[2].value);

    if (!name || amount <= 0 || price < 0) {
        alert("Please enter valid dish info.");
        return;
    }

    const imageFile = dishForm.elements[3].files[0];
    const reader = new FileReader();
        reader.onloadend = () => {
        const imageBase64 = reader.result; 

        const dishData = {
            name: name,
            price: price,
            imagePath: imageBase64,
            stock: stock
        };
        const sessionToken = localStorage.getItem('token');
         if (!sessionToken) {
            alert("Session expired. Please login again.");
            return;
        }
         fetch('http://localhost:8089/dishes/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': sessionToken
            },
            body: JSON.stringify(dishData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to add dish');
            }
            return response.text(); // Because your endpoint returns a simple message
        })
        .then(data => {
            console.log(data);
            alert('Dish added successfully!');
            // You can optionally refresh dish list from backend here
        })
        .catch(error => {
            console.error(error);
            alert('Error adding dish');
        });

        // Optional: Close modal & reset form
        dishModal.style.display = "none";
        dishForm.reset();
        dishImagePreview.src = '';
        dishImagePreview.style.display = 'none';
    };

    if (imageFile) {
        reader.readAsDataURL(imageFile); // Convert to base64
    } else {
        alert("Please select an image for the dish.");
    }
});


    let dishes = getLocalDishes();

if (editingDishId) {
    // Update existing dish
    dishes = dishes.map(d => {
        if (d.id === editingDishId) {
            return { id: d.id, name, amount, price, imageBase64 };
        }
        return d;
    });
} else {
    const newDish = {    
        name,
        amount,
        price,
        imageBase64
    };
    dishes.push(newDish);

    fetch('http://localhost:8080/dishes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: newDish.name,
            amount: newDish.amount,
            price: newDish.price,
            imageBase64: newDish.imageBase64
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to add dish to server');
        }
        return response.json();
    })
    .then(data => {
        console.log('Dish added to server:', data);
    })
    .catch(error => {
        console.error('Error adding dish:', error);
        alert('Failed to add dish to server');
    });
}

saveLocalDishes(dishes);
renderDishes(searchInput.value);

dishModal.style.display = "none";
dishForm.reset();
dishImagePreview.src = '';
dishImagePreview.style.display = 'none';
dishImageInput.value = '';
editingDishId = null;

// Search input event
searchInput.addEventListener("input", (e) => {
    renderDishes(e.target.value);
});

// Sold Dish modal handlers
addSoldDishBtn.addEventListener("click", () => {
    soldForm.reset();
    soldModal.style.display = "flex";
});

document.getElementById("closeSoldModal").addEventListener("click", () => {
    soldModal.style.display = "none";
});

soldForm.addEventListener("submit", e => {
    e.preventDefault();

    const name = soldForm.elements[0].value.trim();
    const customer = soldForm.elements[1].value.trim();
    const shipping = soldForm.elements[2].value.trim();
    const quantity = parseInt(soldForm.elements[3].value);
    const price = parseFloat(soldForm.elements[4].value);

    if (!name || !customer || !shipping || quantity <= 0 || price < 0) {
        alert("Please fill all fields with valid values.");
        return;
    }

    let soldDishes = getLocalSoldDishes();
    soldDishes.push({ name, customer, shipping, quantity, price });
    saveLocalSoldDishes(soldDishes);
    renderSoldDishes();

    soldModal.style.display = "none";
    soldForm.reset();
});

// Initialization
function init() {
    userEmailSpan.textContent = localStorage.getItem('userEmail') || 'seller@example.com';
    renderDishes();
    renderSoldDishes();
}

init();
