package com.Food_delivery.AdminService.Admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LogService {

    private LogRepository logRepository;

    public LogService(LogRepository logRepository) {
        this.logRepository = logRepository;
    }

    public void saveLog(String severity , String message) {
        Log log = new Log(severity, message);
        logRepository.save(log);
    }
    public List<Log> getLogs()
    {
        return logRepository.findAll();
    }
}
