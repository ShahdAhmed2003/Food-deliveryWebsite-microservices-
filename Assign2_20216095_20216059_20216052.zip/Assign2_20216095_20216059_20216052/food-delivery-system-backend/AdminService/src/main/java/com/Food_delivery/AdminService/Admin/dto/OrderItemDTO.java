package com.Food_delivery.AdminService.Admin.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class OrderItemDTO {
    @NotNull
    Long dishId;
    @Min(1)
    int quantity;
    Long sellerId;

    public OrderItemDTO(Long dishId, int quantity, Long sellerId) {
        this.dishId = dishId;
        this.quantity = quantity;
        this.sellerId = sellerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getSellerId() {
        return sellerId;
    }

    public void setDishId(Long dishId) {
        this.dishId = dishId;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Long getDishId() {
        return dishId;
    }

    public int getQuantity() {
        return quantity;
    }

}
