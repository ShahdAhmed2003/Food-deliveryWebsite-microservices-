package com.Food_delivery.AdminService.Admin;


import org.springframework.data.jpa.repository.JpaRepository;



public interface LogRepository extends JpaRepository<Log,Long> {


}
