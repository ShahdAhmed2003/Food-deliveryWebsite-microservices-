package com.Food_delivery.AdminService.Admin;

public class Admin {
    private String email;
    private String password;

}
