package com.Food_delivery.AdminService.Admin.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public class OrderRequestDTO {
    Long id;
    @NotNull
    Long customerId;
    @NotEmpty
    List<OrderItemDTO> items;
    @NotBlank
    private String shippingLocation;
    @NotBlank
    private String shippingCompany;
    private double itemsTotalPrice;
    public double getItemsTotalPrice() {
        return itemsTotalPrice;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setShippingCompany(String shippingCompany) {
        this.shippingCompany = shippingCompany;
    }

    public String getShippingCompany() {
        return shippingCompany;
    }

    public void setItemsTotalPrice(double itemsTotalPrice) {
        this.itemsTotalPrice = itemsTotalPrice;
    }
    public void setShippingLocation(String shippingLocation) {
        this.shippingLocation = shippingLocation;
    }

    public String getShippingLocation() {
        return shippingLocation;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public void setItems(List<OrderItemDTO> items) {
        this.items = items;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public List<OrderItemDTO> getItems() {
        return items;
    }
}