package com.Food_delivery.AdminService.Admin.Messaging;

import com.Food_delivery.AdminService.Admin.LogService;
import com.Food_delivery.AdminService.Admin.dto.LogMessage;
import com.Food_delivery.AdminService.Admin.dto.OrderFailedEvent;
import com.Food_delivery.AdminService.Admin.dto.OrderRequestDTO;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class MessageConsumer {
    LogService ls;

    public MessageConsumer(LogService ls) {
        this.ls = ls;
    }

    @RabbitListener(queues = "admin.payments.failed")
    public void handlePaymentFailed(OrderFailedEvent orderFailedEvent) {
        System.out.println("Payment Failed event" +orderFailedEvent.getId());
        saveLogToDatabase("PaymentFailed","For order number "+orderFailedEvent.getId()+" reason: "+orderFailedEvent.getReason()+" with total price "+ orderFailedEvent.getPrice());

    }
    @RabbitListener(queues = "logs.admin.errors")
    public void listenToAdminErrors(LogMessage logMessage) {
        System.out.println("ADMIN ALERT (Error Log Received): " + logMessage.getMessage());
        saveLogToDatabase(logMessage.getRoutingKey(),logMessage.getMessage());

    }
    private void saveLogToDatabase(String severity, String message) {
              ls.saveLog(severity,message);
    }
}
