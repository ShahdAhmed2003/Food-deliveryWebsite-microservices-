package com.Food_delivery.AdminService.Admin.dto;

public class DishDTO {
    Long id;
    String name;
    double Price;
    int stock;

    public DishDTO(Long id, String name, double price, int stock) {
        this.id = id;
        this.name = name;
        Price = price;
        this.stock = stock;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return Price;
    }

    public int getStock() {
        return stock;
    }
}
