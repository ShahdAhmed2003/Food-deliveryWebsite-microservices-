package ejb;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import User.*;

@Stateless
@LocalBean
public class UserServiceImpl {

	 @Inject
	  private UserRepository userRepository;

    public UserServiceImpl() {
        
    }
    /*@PostConstruct
    public void createDefaultAdmin() {
        String defaultAdminEmail = "admin@system.com";
        String defaultAdminPassword = "admin123";
        String defaultAdminName = "Admin";

      
		if (userRepository.findByEmail(defaultAdminEmail) == null) {
            User admin = new User();
            admin.setEmail(defaultAdminEmail);
            admin.setPassword(defaultAdminPassword);
            admin.setName(defaultAdminName);
            admin.setRole("ADMIN");

            userRepository.save(admin);

            System.out.println("Default Admin account created.");
        } else {
            System.out.println(" Default Admin already exists.");
        }
    }*/

    
    public String register(User user) {
        if (userRepository.findByEmail(user.getEmail()) != null) {
            throw new RuntimeException("Email already exists");
        }
        System.out.println(user.getEmail() + " " + user.getName() + " " + user.getPassword() + " " + user.getRole());

        if (user.getRole() == null) {
            throw new RuntimeException("Role cannot be null");
        }

        if (!user.getRole().equalsIgnoreCase("CUSTOMER") &&
            !user.getRole().equalsIgnoreCase("SELLER") &&
            !user.getRole().equalsIgnoreCase("ADMIN")) {
            throw new RuntimeException("Invalid role");
        }

        if (user.getRole().equalsIgnoreCase("SELLER")) {
            if (userRepository.findByName(user.getName()) != null) {
                throw new RuntimeException("Company name already exists");
            }
            String generatedPassword = generateRandomPassword();
            user.setPassword(generatedPassword);
            userRepository.save(user);
            return "Account created for Company" + user.getName() + " with password: " + generatedPassword;
        }

        userRepository.save(user);
        return "User registered successfully!";
    }

   
    public String Login(String email, String password) {
    	System.out.println(email);
        User user = userRepository.findByEmail(email);
        System.out.println(user.getEmail());

        if (user != null && user.getPassword().equals(password)) {
            String sessionToken = generateRandomToken();
            user.setSessionToken(sessionToken);
            userRepository.save(user);
            return sessionToken;
        } else {
            throw new RuntimeException("Invalid credentials");
        }
    }


    public List<UserDTO> ListCustomers() {
        List<User> customers = userRepository.findByRoleIgnoreCase("CUSTOMER");
        return customers.stream()
                .map(customer -> new UserDTO(
                    customer.getId(),
                    customer.getEmail(),
                    customer.getName(),
                    customer.getRole(),
                    customer.getCreatedAt()
                ))
                .collect(Collectors.toList());
    }

   
    public List<UserDTO> ListSellers() {
        List<User> customers = userRepository.findByRoleIgnoreCase("SELLER");
        return customers.stream()
                .map(customer -> new UserDTO(customer.getId(), customer.getEmail(), customer.getName(), customer.getRole(), customer.getCreatedAt()))
                .collect(Collectors.toList());
    }

    
    public UserDTO getUserBySessionToken(String sessionToken) {
        User user = userRepository.findBySessionToken(sessionToken);
        if (user != null) {
            return new UserDTO(user.getId(), user.getEmail(), user.getName(), user.getRole(), user.getCreatedAt());
        } else {
            throw new RuntimeException("User not found");
        }
    }

    private String generateRandomPassword() {
        int length = 8;
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder password = new StringBuilder();
        for (int i = 0; i < length; i++) {
            password.append(chars.charAt(random.nextInt(chars.length())));
        }
        return password.toString();
    }

    private String generateRandomToken() {
        int length = 32;
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder token = new StringBuilder();
        for (int i = 0; i < length; i++) {
            token.append(chars.charAt(random.nextInt(chars.length())));
        }
        return token.toString();
    }

   
    public String registerCustomer(User user) {
        user.setRole("CUSTOMER");
        return registerInternal(user);
    }

  
    public String registerSeller(User user) {
        user.setRole("SELLER");
        return registerInternal(user);
    }

    private String registerInternal(User user) {
        if (userRepository.findByEmail(user.getEmail()) != null) {
            throw new RuntimeException("Email already exists");
        }

        System.out.println(user.getEmail() + " " + user.getName() + " " + user.getPassword() + " " + user.getRole());

        if (user.getRole().equalsIgnoreCase("SELLER")) {
            if (userRepository.findByName(user.getName()) != null) {
                throw new RuntimeException("Company name already exists");
            }
            String generatedPassword = generateRandomPassword();
            user.setPassword(generatedPassword);
            userRepository.save(user);
            return "Account created for Company " + user.getName() + " with password: " + generatedPassword;
        }

        userRepository.save(user);
        return "User registered successfully!";
    }

    
    public UserDTO getUserById(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
        return new UserDTO(user.getId(), user.getEmail(), user.getName(), user.getRole(), user.getCreatedAt());
    }
}