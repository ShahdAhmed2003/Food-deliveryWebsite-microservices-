package ejb;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;
import User.*;

@Singleton
@Startup  
@LocalBean
public class DefaultAdminCreator {

    @Inject
    private UserRepository userRepository;

    @PostConstruct
    public void createDefaultAdmin() {
        String defaultAdminEmail = "admin@system.com";
        String defaultAdminPassword = "admin123";
        String defaultAdminName = "Admin";

        if (userRepository.findByEmail(defaultAdminEmail) == null) {
            User admin = new User();
            admin.setEmail(defaultAdminEmail);
            admin.setPassword(defaultAdminPassword);
            admin.setName(defaultAdminName);
            admin.setRole("ADMIN");

            userRepository.save(admin);
            System.out.println("Default Admin account created.");
        } else {
            System.out.println("Default Admin already exists.");
        }
    }
}

