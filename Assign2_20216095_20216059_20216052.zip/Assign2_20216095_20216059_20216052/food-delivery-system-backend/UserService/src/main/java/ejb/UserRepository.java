package ejb;
import java.util.List;
import java.util.Optional;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import User.User;


public class UserRepository {

	@PersistenceContext(unitName = "food")
	private EntityManager em;

    // Equivalent to findByEmail()
    public User findByEmail(String email) {
        TypedQuery<User> query = em.createQuery(
            "SELECT u FROM User u WHERE u.email = :email", User.class);
        query.setParameter("email", email);
        return query.getResultStream().findFirst().orElse(null);
    }

    // Equivalent to findByName()
    public User findByName(String name) {
        TypedQuery<User> query = em.createQuery(
            "SELECT u FROM User u WHERE u.name = :name", User.class);
        query.setParameter("name", name);
        return query.getResultStream().findFirst().orElse(null);
    }

    // Equivalent to findByRoleIgnoreCase()
    public List<User> findByRoleIgnoreCase(String role) {
        TypedQuery<User> query = em.createQuery(
            "SELECT u FROM User u WHERE LOWER(u.role) = LOWER(:role)", User.class);
        query.setParameter("role", role);
        return query.getResultList();
    }

    // Equivalent to findBySessionToken()
    public User findBySessionToken(String sessionToken) {
        TypedQuery<User> query = em.createQuery(
            "SELECT u FROM User u WHERE u.sessionToken = :sessionToken", User.class);
        query.setParameter("sessionToken", sessionToken);
        return query.getResultStream().findFirst().orElse(null);
    }

    // Additional CRUD methods (optional)
    public User save(User user) {
        if (user.getId() == null) {
            em.persist(user);
            return user;
        } else {
            return em.merge(user);
        }
    }

    public void delete(User user) {
        em.remove(em.contains(user) ? user : em.merge(user));
    }
    public Optional<User> findById(Long id) {
        return Optional.ofNullable(em.find(User.class, id));
    }
}