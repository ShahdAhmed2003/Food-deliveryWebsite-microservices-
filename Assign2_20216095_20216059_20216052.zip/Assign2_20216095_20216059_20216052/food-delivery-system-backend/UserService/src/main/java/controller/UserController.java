package controller;




import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

import User.User;
import User.UserDTO;
import ejb.UserServiceImpl;

import java.util.List;
@Path("/auth")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UserController {

    @Inject
    private UserServiceImpl userService ;

    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response login(@FormParam("email") String email, @FormParam("password") String password) {
        try {
            String response = userService.Login(email, password);
            return Response.ok(response).build(); // HTTP 200 OK
        } catch (RuntimeException ex) {
            return Response.status(Response.Status.UNAUTHORIZED).entity(ex.getMessage()).build(); // 401 Unauthorized
        }
    }

    @GET
    @Path("/customers")
    public Response listCustomers() {
        List<UserDTO> customers = userService.ListCustomers();
        return Response.ok(customers).build();
    }

    @GET
    @Path("/sellers")
    public Response listSellers() {
        List<UserDTO> sellers = userService.ListSellers();
        return Response.ok(sellers).build();
    }

    @GET
    @Path("/me")
    public Response getUserBySessionToken(@HeaderParam("Authorization") String sessionToken) {
        try {
            UserDTO userDTO = userService.getUserBySessionToken(sessionToken);
            return Response.ok(userDTO).build();
        } catch (RuntimeException ex) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
    }

    @POST
    @Path("/register-customer")
    public Response registerCustomer(User user) {
        try {
            String response = userService.registerCustomer(user);
            return Response.status(Response.Status.CREATED).entity(response).build();
        } catch (RuntimeException ex) {
            return Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
        }
    }

    @POST
    @Path("/register-seller")
    public Response registerSeller(User user) {
        try {
            String response = userService.registerSeller(user);
            return Response.status(Response.Status.CREATED).entity(response).build();
        } catch (RuntimeException ex) {
            return Response.status(Response.Status.BAD_REQUEST).entity(ex.getMessage()).build();
        }
    }

    @GET
    @Path("/me/id")
    public Response getUserIdFromSessionToken(@HeaderParam("Authorization") String sessionToken) {
        try {
            UserDTO userDTO = userService.getUserBySessionToken(sessionToken);
            return Response.ok(userDTO.getId()).build();
        } catch (RuntimeException ex) {
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }
    }

    @GET
    @Path("/{userId}")
    public Response getUserById(@PathParam("userId") Long userId) {
        try {
            UserDTO userDTO = userService.getUserById(userId);
            return Response.ok(userDTO).build();
        } catch (RuntimeException ex) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }
}
