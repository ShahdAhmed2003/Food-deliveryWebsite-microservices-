package com.Food_delivery.DishService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DishServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
