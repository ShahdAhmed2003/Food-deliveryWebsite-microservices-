package com.Food_delivery.DishService.Dish;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import org.springframework.lang.NonNull;

@Entity
public class Dish {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long dishId;
   @Column(nullable = false)
   private String name;
    @Column(nullable = false)
   private double price;
    @Column(columnDefinition = "text")
    private String description;
    @Column(nullable = false)
    private String imagePath;
    @Column(nullable = false)
    private int stock;
    private Long sellerId;
    private Long customerId;
    private  String sellername;

    public void setSellername(String sellername) {
        this.sellername = sellername;
    }

    public String getSellername() {
        return sellername;
    }

    public Dish() {
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setSellerId(Long sellerId) {
        this.sellerId = sellerId;
    }

    public Long getSellerId() {
        return sellerId;
    }


    public Dish(Long dishId, String name, double price, String description, String imagePath, int stock, Long sellerId, Long customerId,String sellername) {
        this.dishId = dishId;
        this.name = name;
        this.price = price;
        this.description = description;
        this.imagePath = imagePath;
        this.stock = stock;
        this.sellerId = sellerId;
        this.customerId = customerId;
        this.sellername=sellername;

    }

    public void setDishId(Long dishId) {
        this.dishId = dishId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }


    public Long getDishId() {
        return dishId;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public String getImagePath() {
        return imagePath;
    }

    public int getStock() {
        return stock;
    }
}
