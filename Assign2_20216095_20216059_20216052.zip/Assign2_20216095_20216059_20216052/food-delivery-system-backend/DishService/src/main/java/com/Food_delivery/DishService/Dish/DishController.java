package com.Food_delivery.DishService.Dish;

import com.Food_delivery.DishService.Dish.dto.DishDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/dishes")
public class DishController {
    private DishService dishService;
    private  DishRepository repository;

    public DishController(DishService dishService, DishRepository repository) {
        this.dishService = dishService;
        this.repository = repository;
    }

    @PostMapping("/create")
    public ResponseEntity<String> createDish(@RequestHeader("Authorization") String sessionToken, @RequestBody Dish dish) {
        try {
            // Call the service method to add the dish
            dishService.addDish(sessionToken, dish);

            return new ResponseEntity<>("Dish created successfully", HttpStatus.CREATED);
        } catch (RuntimeException e) {

            return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    @GetMapping("/stock/{dishId}")
    public ResponseEntity<String> checkDishStock(@PathVariable Long dishId) {
        try {
            int stock = dishService.checkDishStock(dishId);
            return ResponseEntity.ok("The stock of dish with ID " + dishId + " is: " + stock);
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<DishDTO> getDish(@PathVariable Long id) {
        return repository.findById(id)
                .map(d -> new DishDTO(d.getDishId(), d.getName(), d.getPrice(), d.getStock()))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    @GetMapping("/price/{dishId}")
    public Double getDishPrice(@PathVariable Long dishId) {
        return dishService.getDishPrice(dishId);
    }
    @PutMapping("/update-stock/{dishId}")
    public ResponseEntity<String> updateDishStock(
            @PathVariable Long dishId,
            @RequestParam int quantityChange) {
        try{
            dishService.updateDishStock(dishId,quantityChange);
            return ResponseEntity.ok("The stock of dish with ID " + dishId + " is updated");

        }catch(RuntimeException e)
        {
            return ResponseEntity.status(400).body("Error: " + e.getMessage());
        }


    }
    @GetMapping("/seller-dishes")
    public ResponseEntity<?> getDishesBySeller(@RequestHeader("Authorization") String sessionToken) {
        try {
            List<Dish> dishes = dishService.getDishesBySeller(sessionToken);
            if (dishes.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No dishes found for this seller.");
            }
            return ResponseEntity.ok(dishes);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error: " + e.getMessage());
        }
    }
    @PutMapping("/{dishId}")
    public ResponseEntity<Dish> updateDishInfo(
            @RequestHeader("Authorization") String sessionToken,
            @PathVariable Long dishId,
            @RequestBody Dish updatedDish) {

        Dish updated = dishService.updateDishInfo(sessionToken, dishId, updatedDish);
        return ResponseEntity.ok(updated);
    }
    @GetMapping
    public ResponseEntity<List<Dish>> getAllDishes() {
        List<Dish> dishes = dishService.getAllDishes();
        return ResponseEntity.ok(dishes);
    }




}
