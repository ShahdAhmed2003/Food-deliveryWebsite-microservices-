package com.Food_delivery.DishService.Dish.messaging;
import com.Food_delivery.DishService.Dish.Dish;
import com.Food_delivery.DishService.Dish.DishService;
import com.Food_delivery.DishService.Dish.dto.*;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.web.client.RestTemplate;

@Service
public class MessageConsumer {
    DishService dishService;
    private final RabbitTemplate rabbitTemplate;
    private RestTemplate restTemplate;
    private static final String USER_SERVICE_URL = "http://localhost:8080/UserService/api/auth";

    public MessageConsumer(DishService dishService,RabbitTemplate rabbitTemplate,RestTemplate restTemplate) {
        this.dishService = dishService;
        this.rabbitTemplate=rabbitTemplate;
        this.restTemplate=restTemplate;
    }
@RabbitListener(queues="ShippingFailure")
public void rollback(OrderFailedEvent order)
{
    System.out.println("Restocking Back");
    for(OrderItemDTO item:order.getItems())
    {
        sendLog("Stock_Info", "Restocking dish number"+item.getDishId());
        int currentStock = dishService.checkDishStock(item.getDishId());
        dishService.updateDishStock(item.getDishId(),currentStock+ item.getQuantity());
    }
}@RabbitListener(queues="PaymentFailure")
    public void rollback2(OrderFailedEvent order)
    {
        System.out.println("Restocking Back");
        for(OrderItemDTO item:order.getItems())
        {
            sendLog("Stock_Info", "Restocking dish number"+item.getDishId());
            int currentStock = dishService.checkDishStock(item.getDishId());
            dishService.updateDishStock(item.getDishId(),currentStock+ item.getQuantity());
        }
    }

    @RabbitListener(queues = "OrderRequestQueue")
    public void consumeMessage(OrderRequestDTO orderRequestDTO) {
        System.out.println("Checking Stock for Order Number: "+orderRequestDTO.getId());
        double itemsTotalPrice = dishService.calculateItemsTotalPrice(orderRequestDTO.getItems());
        boolean allInStock = orderRequestDTO.getItems().stream()
                .allMatch(item -> {
                    Dish dish=dishService.getDish(item.getDishId());
                    item.setSellerId(dish.getSellerId());//mohema dy 3ashan lama n check el item sold wla la2 for each seller
                    int availableStock = dishService.checkDishStock(item.getDishId());
                    return availableStock >= item.getQuantity();


                });
        if(allInStock)
        {
            orderRequestDTO.setItemsTotalPrice(itemsTotalPrice);
            orderRequestDTO.getItems().forEach(item -> {
                int currentStock = dishService.checkDishStock(item.getDishId());
                dishService.updateDishStock(
                        item.getDishId(),
                        currentStock - item.getQuantity()
                );
                dishService.updateDishCustomer(item.getDishId(),orderRequestDTO.getCustomerId());
                if (dishService.checkDishStock(item.getDishId())<=10) {
                    sendLog("Stock_Warning,", "Heads up! Stock is running low for Dish " + item.getDishId());
                }
            });
            rabbitTemplate.convertAndSend("ShippingConfirmation",orderRequestDTO);
            sendLog("Stock_Info", "Stock confirmed and updated for orderId: " + orderRequestDTO.getId());

        }
        else
        {
            rabbitTemplate.convertAndSend("OrderFailedQueue",
            new OrderFailedEvent(orderRequestDTO.getId(),"Insufficient Stock ",
            orderRequestDTO.getItems(),itemsTotalPrice));
            sendLog("Stock.Error", "InSufficient Stock for orderId: " + orderRequestDTO.getId());
        }



    }
    private void sendLog(String routingKey, String message) {
        LogMessage logMessage = new LogMessage(routingKey, message);
        rabbitTemplate.convertAndSend("log.exchange", routingKey, logMessage);
        System.out.println("[LOG SENT] " + routingKey + ": " + message);
    }
    private UserDTO getUserBySessionToken(String sessionToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", sessionToken);

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<UserDTO> response = restTemplate.exchange(
                USER_SERVICE_URL + "/me",
                HttpMethod.GET,
                entity,
                UserDTO.class
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else {
            throw new RuntimeException("Invalid or expired session token.");
        }
    }


}
