package com.Food_delivery.DishService.Dish.Impl;


import com.Food_delivery.DishService.Dish.Dish;
import com.Food_delivery.DishService.Dish.DishRepository;
import com.Food_delivery.DishService.Dish.DishService;
import com.Food_delivery.DishService.Dish.dto.OrderItemDTO;
import com.Food_delivery.DishService.Dish.dto.UserDTO;
import jakarta.transaction.Transactional;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class DishServiceImpl implements DishService {
    private DishRepository dishRepository;
    private final RestTemplate restTemplate;
    //private final String sellerServiceUrl = "http://localhost:8087/seller";
    private static final String USER_SERVICE_URL = "http://localhost:8080/UserService/api/auth";



    public DishServiceImpl(DishRepository dishRepository, RestTemplate restTemplate) {
        this.dishRepository = dishRepository;
        this.restTemplate = restTemplate;
    }


    @Override
    public List<Dish> getDishesBySeller(String sessionToken)
    { UserDTO userDTO = getUserBySessionToken(sessionToken);

        return dishRepository.findBySellerId(userDTO.getId());
    }


    @Override
    public Dish getDish(Long dishId) {
        return dishRepository.findById(dishId).orElseThrow(() -> new RuntimeException("Dish not found"));
    }

    @Override
    public Dish addDish(String sessionToken, Dish dish)
    {

        UserDTO userDTO = getUserBySessionToken(sessionToken);
        if (!userDTO.getRole().equalsIgnoreCase("SELLER")) {

            throw new RuntimeException("Only Sellers Add Dishes.");
        }
        dish.setSellerId(userDTO.getId());// each dish belongs to a seller
        dish.setSellername(userDTO.getName());
        return dishRepository.save(dish);

    }

    @Override
    public int checkDishStock(Long dishId) {
        Dish dish=dishRepository.findById(dishId).orElseThrow(() -> new RuntimeException("Dish not found"));
        return dish.getStock();
    }

    @Override
    public double getDishPrice(Long dishId) {
        Dish dish=dishRepository.findById(dishId).orElseThrow(() -> new RuntimeException("Dish not found"));
        return dish.getPrice();

    }


    @Override
    public void updateDishStock(Long dishId,int Stock) {
    Dish dish=dishRepository.findById(dishId).orElseThrow(() -> new RuntimeException("Dish not found"));
    dish.setStock(Stock);
    dishRepository.save(dish);
    }
   @Override
    public void updateDishCustomer(Long dishId,Long customerId) {
        Dish dish=dishRepository.findById(dishId).orElseThrow(() -> new RuntimeException("Dish not found"));
        dish.setCustomerId(customerId);
        dishRepository.save(dish);
    }
    @Override
    public double calculateItemsTotalPrice(List<OrderItemDTO> items) {
        return items.stream()
                .mapToDouble(item -> {
                    double dishPrice = getDishPrice(item.getDishId());
                    return dishPrice * item.getQuantity();
                })
                .sum();
    }
    private UserDTO getUserBySessionToken(String sessionToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", sessionToken);

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<UserDTO> response = restTemplate.exchange(
                USER_SERVICE_URL + "/me",
                HttpMethod.GET,
                entity,
                UserDTO.class
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else {
            throw new RuntimeException("Invalid or expired session token.");
        }
    }
    @Transactional
    @Override
    public Dish updateDishInfo(String sessionToken, Long dishId, Dish updatedDish) {
        // Verify user is seller
        UserDTO user = getUserBySessionToken(sessionToken);
        if (!"SELLER".equalsIgnoreCase(user.getRole())) {
            throw new RuntimeException("Only sellers can update dishes");
        }
        System.out.println(updatedDish.getName());
        System.out.println(updatedDish.getDescription());
        System.out.println(updatedDish.getStock());
        System.out.println(updatedDish.getPrice());



        Dish existingDish = dishRepository.findById(dishId)
                .orElseThrow(() -> new RuntimeException("Dish not found"));


        if (!existingDish.getSellerId().equals(user.getId())) {
            throw new RuntimeException("You can only update your own dishes");
        }

        // Apply updates
        if (updatedDish.getName() != null && !updatedDish.getName().trim().isEmpty()) {
            existingDish.setName(updatedDish.getName());
        }

        if (updatedDish.getDescription() != null && !updatedDish.getDescription().trim().isEmpty()) {
            existingDish.setDescription(updatedDish.getDescription());
        }

        if (updatedDish.getStock() >= 0) {
            existingDish.setStock(updatedDish.getStock());
        }
        if (updatedDish.getImagePath() != null && !updatedDish.getImagePath().trim().isEmpty()) {
            existingDish.setImagePath(updatedDish.getImagePath());
        }

        return dishRepository.save(existingDish);
    }



    @Override
    public List<Dish> getAllDishes() {
        return dishRepository.findAll();
    }

}
