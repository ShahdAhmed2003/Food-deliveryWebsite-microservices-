package com.Food_delivery.DishService.Dish;

import com.Food_delivery.DishService.Dish.dto.OrderItemDTO;

import java.util.List;

public interface DishService {

    List<Dish> getDishesBySeller( String sessionToken);

    public Dish getDish(Long dishId);
    Dish addDish(String sessionToken, Dish dish);

    public int checkDishStock(Long dishId);
    public double getDishPrice(Long dishId);
    public void updateDishStock(Long dishId,int Stock);
    public double calculateItemsTotalPrice(List<OrderItemDTO> items);
    public void updateDishCustomer(Long dishId,Long customerId);

    Dish updateDishInfo(String sessionToken, Long dishId, Dish updatedDish);
    List<Dish> getAllDishes();

}
