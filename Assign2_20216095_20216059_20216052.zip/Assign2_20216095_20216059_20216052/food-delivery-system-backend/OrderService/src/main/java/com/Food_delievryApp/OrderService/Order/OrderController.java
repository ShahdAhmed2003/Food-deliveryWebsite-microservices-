package com.Food_delievryApp.OrderService.Order;

import com.Food_delievryApp.OrderService.Order.dto.OrderRequestDTO;
import com.Food_delievryApp.OrderService.Order.dto.OrderResponseDTO;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderService orderService;
    OrderRepository orderRepository;

    public OrderController(OrderService orderService,OrderRepository orderRepository) {
        this.orderService = orderService;
        this.orderRepository=orderRepository;
    }

    @PostMapping("/makeOrder")
    public ResponseEntity<?> placeOrder(@RequestBody OrderRequestDTO request,@RequestHeader("Authorization") String sessionToken) {
        try {
            Order createdOrder = orderService.placeOrder(request,sessionToken);

            return ResponseEntity.ok("Order "+createdOrder.getId()+" "+createdOrder.getStatus());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new OrderResponseDTO(
                            e.getMessage(),
                            HttpStatus.BAD_REQUEST.value(),
                            false
                    ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new OrderResponseDTO(
                            "Internal server error: " + e.getMessage(),
                            HttpStatus.INTERNAL_SERVER_ERROR.value(),
                            false
                    ));
        }
    }
    @GetMapping
    public ResponseEntity<List<Order>> findAll() {
        List<Order> orders = orderRepository.findAll();
        return ResponseEntity.ok(orders);
    }


    @GetMapping("/sold-items")
    public ResponseEntity<List<SoldItemDTO>> getSoldItemsBySeller(@RequestHeader("Authorization") String sessionToken) {
        List<SoldItemDTO> soldItems = orderService.getSoldDishes(sessionToken);

        if (soldItems.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(soldItems);
    }
    @GetMapping("/customer")
    public ResponseEntity<List<Order>> getCustomerOrders(@RequestHeader("Authorization") String sessionToken) {
        List<Order> orders = orderService.getCustomerOrders(sessionToken);
        return ResponseEntity.ok(orders);
    }

}
