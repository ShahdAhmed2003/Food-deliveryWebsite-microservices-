package com.Food_delievryApp.OrderService.Order.messaging;

import com.Food_delievryApp.OrderService.Order.Order;
import com.Food_delievryApp.OrderService.Order.OrderRepository;
import com.Food_delievryApp.OrderService.Order.OrderService;
import com.Food_delievryApp.OrderService.Order.dto.OrderFailedEvent;
import com.Food_delievryApp.OrderService.Order.dto.OrderItemDTO;
import com.Food_delievryApp.OrderService.Order.dto.OrderRequestDTO;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MessageConsumer {
    OrderService orderService;
    public OrderRepository orderRepository;
    public RabbitTemplate rabbitTemplate;
    private RestTemplate restTemplate;
    MessageProducer messageProducer;


    public MessageConsumer(OrderService orderService, OrderRepository orderRepository, RabbitTemplate rabbitTemplate, RestTemplate restTemplate, MessageProducer messageProducer) {
        this.orderService = orderService;
        this.orderRepository = orderRepository;
        this.rabbitTemplate = rabbitTemplate;
        this.restTemplate = restTemplate;
        this.messageProducer = messageProducer;
    }

    @RabbitListener(queuesToDeclare = @Queue(name = "OrderFailedQueue", durable = "true"))
    public void consumeFailureMessage(OrderFailedEvent order) {
        System.out.println("Rolling Back Order  number: " + order.getId());
        orderService.updateOrderStatus(order.getId(),"Cancelled");
        orderService.updatePrice(order.getId(),order.getPrice());
        Order orderr = orderRepository.findById(order.getId())
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + order.getId()));


        for (Order.OrderItem item : orderr.getItems()) {

            order.getItems()
                    .stream()
                    .filter(dtoItem -> dtoItem.getDishId().equals(item.getDishId()))
                    .findFirst()
                    .ifPresent(dtoItem -> {
                        item.setSellerId(dtoItem.getSellerId());
                    });
        }

        orderRepository.save(orderr);
    }





    @RabbitListener(queuesToDeclare = @Queue(name = "OrderConfirmedQueue", durable = "true"))
    public void consumeConfirmationMessage(OrderRequestDTO order) {
        orderService.updateOrderStatus(order.getId(), "Confirmed");
        orderService.updatePrice(order.getId(), order.getItemsTotalPrice());

        Optional<Order> optionalOrder = orderRepository.findById(order.getId());
        if (optionalOrder.isEmpty()) {
            System.out.println("Order not found with id: " + order.getId());
            return; // gracefully exit the method
        }

        Order orderr = optionalOrder.get();


        for (Order.OrderItem item : orderr.getItems()) {
            System.out.println("OrderItem DishId: " + item.getDishId() + ", Current SellerId: " + item.getSellerId());

            order.getItems()
                    .stream()
                    .filter(dtoItem -> {
                        System.out.println("DTO DishId: " + dtoItem.getDishId() + ", DTO SellerId: " + dtoItem.getSellerId());
                        return dtoItem.getDishId().equals(item.getDishId());
                    })
                    .findFirst()
                    .ifPresentOrElse(
                            dtoItem -> {
                                item.setSellerId(dtoItem.getSellerId());
                                System.out.println("Updated SellerId to: " + dtoItem.getSellerId());
                            },
                            () -> System.out.println("No matching DTO item for DishId: " + item.getDishId())
                    );
        }

        orderRepository.save(orderr);
    }




}