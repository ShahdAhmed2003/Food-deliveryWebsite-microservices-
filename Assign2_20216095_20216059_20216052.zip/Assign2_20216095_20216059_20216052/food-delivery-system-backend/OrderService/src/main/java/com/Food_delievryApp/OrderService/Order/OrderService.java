package com.Food_delievryApp.OrderService.Order;

import com.Food_delievryApp.OrderService.Order.dto.*;
import com.Food_delievryApp.OrderService.Order.messaging.MessageProducer;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {
    public OrderRepository orderRepository;
    public RabbitTemplate rabbitTemplate;
    private RestTemplate restTemplate;
    MessageProducer messageProducer;
    private static final String USER_SERVICE_URL = "http://localhost:8080/UserService/api/auth";
    public OrderService(OrderRepository orderRepository, RabbitTemplate rabbitTemplate, RestTemplate restTemplate, MessageProducer messageProducer) {
        this.orderRepository = orderRepository;
        this.rabbitTemplate = rabbitTemplate;
        this.restTemplate = restTemplate;
        this.messageProducer = messageProducer;
    }

    public Order placeOrder(OrderRequestDTO request,String sessionToken) {
        Order order = new Order();
        order.setStatus("Pending");
        UserDTO userDTO = getUserBySessionToken(sessionToken);
        if (!userDTO.getRole().equalsIgnoreCase("CUSTOMER")) {
            sendLog("Order_Error", "Failed to verify Customer: ");
            throw new RuntimeException("Only customers can place orders.");
        }
        sendLog("Order_Info", "Order placed by customer " + userDTO.getId());
        order.setCustomerId(userDTO.getId());

        List<Order.OrderItem> orderItems = request.getItems().stream()
                .map(this::convertToOrderItem)
                .toList();
        //order.setCustomerId(request.getCustomerId());
        order.setItems(orderItems);
        order.setShippingLocation(request.getShippingLocation());
        order.setShippingCompany(request.getShippingCompany());
        order=orderRepository.save(order);
        messageProducer.sendOrderRequest(order);
        sendLog("Order_Info", "Order "+order.getId()+" saved and sent to processing: " );
        return order;
        }

    private Order.OrderItem convertToOrderItem(OrderItemDTO itemDTO) {
        Order.OrderItem item = new Order.OrderItem();
        item.setDishId(itemDTO.getDishId());
        item.setQuantity(itemDTO.getQuantity());
        return item;
    }
    private List<Order>Findall()
    {
        return orderRepository.findAll();
    }


    public Order updateOrderStatus(Long orderId, String newStatus) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> {
                    sendLog("Order_Error", "Order not found with id: " + orderId);
                    return new RuntimeException("Order not found with id: " + orderId);
                });

        order.setStatus(newStatus);
        sendLog("Order_Info", "Order status updated to: " + newStatus + " for orderId: " + orderId);
        System.out.println(order.getId() + order.getStatus());
        return orderRepository.save(order);
    }
    public Order updatePrice(Long orderId,double price) {
        // Find order by ID
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + orderId));

        // Update the status
        order.setItemsTotalPrice(price);

        return orderRepository.save(order);
    }
    private void sendLog(String routingKey, String message) {
        rabbitTemplate.convertAndSend("log.exchange", routingKey, message);
        System.out.println("[LOG SENT] " + routingKey + ": " + message);
    }

    private UserDTO getUserBySessionToken(String sessionToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", sessionToken);

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<UserDTO> response = restTemplate.exchange(
                USER_SERVICE_URL + "/me",
                HttpMethod.GET,
                entity,
                UserDTO.class
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            return response.getBody();
        } else {
            throw new RuntimeException("Invalid or expired session token.");
        }

    }
    public List<SoldItemDTO> getSoldDishes(String sessionToken)
    {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", sessionToken);

        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<UserDTO> response = restTemplate.exchange(
                USER_SERVICE_URL + "/me",
                HttpMethod.GET,
                entity,
                UserDTO.class
        );
        UserDTO userDTO=response.getBody();
        System.out.println("Seller "+userDTO.getId());
        List<Order> orders = orderRepository.findOrdersWithSoldItemsBySellerId(userDTO.getId());//hena byerga3 list of orders
        List<SoldItemDTO> soldItems = new ArrayList<>();
        for (Order order : orders) {
            System.out.println("Orders"+order.getId());
            for (Order.OrderItem item : order.getItems()) {
                if (item.getSellerId().equals(userDTO.getId())) {
                    SoldItemDTO dto = new SoldItemDTO();
                    dto.setDishId(item.getDishId());
                    dto.setQuantity(item.getQuantity());
                    dto.setOrderId(order.getId());
                    dto.setCustomerId(order.getCustomerId());
                    dto.setShippingCompany(order.getShippingCompany());
                    dto.setTotalPrice(order.getItemsTotalPrice());
                    UserDTO customer = getUserById(order.getCustomerId());
                    if (customer != null) {
                        dto.setCustomerName(customer.getName());
                        dto.setCustomerEmail(customer.getEmail());
                    }
                    soldItems.add(dto);
                }
            }

        }

        return soldItems;
    }
    private UserDTO getUserById(Long userId) {
        try {
            String url = "http://localhost:8080/UserService/api/auth/" + userId;
            ResponseEntity<UserDTO> response = restTemplate.getForEntity(url, UserDTO.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                return response.getBody();
            } else {
                return null;
            }
        } catch (Exception e) {
            System.out.println("Failed to fetch user data: " + e.getMessage());
            return null;
        }
    }
    public List<Order> getCustomerOrders(String sessionToken) {

        UserDTO userDTO = getUserBySessionToken(sessionToken);
        if (!userDTO.getRole().equalsIgnoreCase("CUSTOMER")) {
            sendLog("Order_Error", "Failed to verify Customer: ");
            throw new RuntimeException("Only customers can view their orders.");
        }


        List<Order> customerOrders = orderRepository.findByCustomerId(userDTO.getId());

        // Step 3: Logging
        sendLog("Order_Info", "Retrieved " + customerOrders.size() + " orders for customer " + userDTO.getId());

        return customerOrders;
    }



}

