package com.Food_delievryApp.ShippingService;
import org.springframework.stereotype.Service;

import java.util.List;

    @Service
    public class ShippingCompanyService {

        private final ShippingCompanyRepository shippingCompanyRepository;

        public ShippingCompanyService(ShippingCompanyRepository shippingCompanyRepository) {
            this.shippingCompanyRepository = shippingCompanyRepository;
        }

        public ShippingCompany createShippingCompany(ShippingCompany company) {
            if (shippingCompanyRepository.existsByName(company.getName())) {
                throw new RuntimeException("Shipping company with name '" + company.getName() + "' already exists.");
            }
            return shippingCompanyRepository.save(company);
        }

        public List<ShippingCompany> getAllShippingCompanies() {
            return shippingCompanyRepository.findAll();
        }
    }

