package com.Food_delievryApp.ShippingService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/shipping/companies")
public class ShippingCompanyController {

    private final ShippingCompanyService shippingCompanyService;

    public ShippingCompanyController(ShippingCompanyService shippingCompanyService) {
        this.shippingCompanyService = shippingCompanyService;
    }

    // a. Create Shipping Company
    @PostMapping
    public ResponseEntity<ShippingCompany> createShippingCompany(@RequestBody ShippingCompany company) {
        try {
            ShippingCompany saved = shippingCompanyService.createShippingCompany(company);
            return ResponseEntity.ok(saved);
        } catch (RuntimeException ex) {
            // Log the error if needed
            System.out.println("Error creating shipping company: " + ex.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        } catch (Exception ex) {
            System.out.println("Unexpected error: " + ex.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }


    // b. List all Shipping Companies
    @GetMapping
    public ResponseEntity<List<ShippingCompany>> getAllShippingCompanies() {
        List<ShippingCompany> companies = shippingCompanyService.getAllShippingCompanies();
        return ResponseEntity.ok(companies);
    }
}