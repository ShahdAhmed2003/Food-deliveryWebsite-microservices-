package com.Food_delievryApp.ShippingService.messaging;


import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfiguration {
    @Bean
    public Queue makingOrder(){
        return new Queue("OrderRequestQueue");

    }
    @Bean
    public Queue orderConfirmedQueue()
    {
        return new Queue("OrderConfirmedQueue");

    }
    @Bean
    public Queue orderRejectedQueue()
    {
        return new Queue("OrderRejectedQueue");

    }
    @Bean
    public MessageConverter jsonMessageConverter()
    {
       return new Jackson2JsonMessageConverter();
    }
    @Bean
    public RabbitTemplate rabbitTemplate(final ConnectionFactory connectionFactory)
    {
        RabbitTemplate rabbitTemplate=new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(jsonMessageConverter());
        return rabbitTemplate;

    }
    @Bean
    public Queue orderPaymentQueue()
    {
        return new Queue("OrderPaymentQueue");

    }
    @Bean
    public Queue orderFailedQueue()
    {
        return new Queue("OrderFailedQueue");

    }
    @Bean
    public Queue PaymentFailure() {
        return new Queue("PaymentFailure");
    }
    @Bean
    public Queue ShippingQueue()
    {
        return new Queue("ShippingConfirmation");
    }
    @Bean
    public Queue ShippingFailureQueue()
    {
        return new Queue("ShippingFailure");
    }
    @Bean
    public TopicExchange logExchange() {
        return new TopicExchange("log.exchange");
    }
    @Bean
    public Queue allLogsQueue() {
        return new Queue("logs.all");
    }

    @Bean
    public Queue adminErrorLogsQueue() {
        return new Queue("logs.admin.errors");
    }
    @Bean
    public Binding allLogsBinding(TopicExchange logExchange, Queue allLogsQueue) {
        return BindingBuilder.bind(allLogsQueue)
                .to(logExchange)
                .with("#");
    }
    @Bean
    public Binding adminErrorsBinding(TopicExchange logExchange, Queue adminErrorLogsQueue) {
        return BindingBuilder.bind(adminErrorLogsQueue)
                .to(logExchange)
                .with("*.Error");
    }

}
