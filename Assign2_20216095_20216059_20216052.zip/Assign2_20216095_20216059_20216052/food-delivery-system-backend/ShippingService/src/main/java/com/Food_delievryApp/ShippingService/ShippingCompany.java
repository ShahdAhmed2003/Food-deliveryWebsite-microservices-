package com.Food_delievryApp.ShippingService;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;
import java.util.List;

@Entity
public class ShippingCompany {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    @ElementCollection(fetch = FetchType.EAGER)
    List<String>regions;
    double shipping_fees;
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }


    public ShippingCompany() {
    }

    public ShippingCompany(Long id, String name, List<String> regions, double shipping_fees) {
        this.id = id;
        this.name = name;
        this.regions = regions;
        this.shipping_fees = shipping_fees;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegions(List<String> regions) {
        this.regions = regions;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<String> getRegions() {
        return regions;
    }

    public void setShipping_fees(double shipping_fees) {
        this.shipping_fees = shipping_fees;
    }

    public double getShipping_fees() {
        return shipping_fees;
    }
}
