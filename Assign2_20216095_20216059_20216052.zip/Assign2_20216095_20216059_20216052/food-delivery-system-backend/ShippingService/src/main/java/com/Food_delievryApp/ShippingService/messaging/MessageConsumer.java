package com.Food_delievryApp.ShippingService.messaging;


import com.Food_delievryApp.ShippingService.ShippingCompany;
import com.Food_delievryApp.ShippingService.ShippingCompanyRepository;
import com.Food_delievryApp.ShippingService.ShippingCompanyService;
import com.Food_delievryApp.ShippingService.dto.LogMessage;
import com.Food_delievryApp.ShippingService.dto.OrderFailedEvent;
import com.Food_delievryApp.ShippingService.dto.OrderRequestDTO;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class MessageConsumer {
    private final ShippingCompanyRepository shippingCompanyRepository;
    private  RabbitTemplate rabbitTemplate;

    public MessageConsumer(ShippingCompanyRepository shippingCompanyRepository, RabbitTemplate rabbitTemplate) {
        this.shippingCompanyRepository = shippingCompanyRepository;
        this.rabbitTemplate = rabbitTemplate;
    }

    @RabbitListener(queues = "ShippingConfirmation")
    public void consumeMessage(OrderRequestDTO orderRequestDTO) {
        System.out.println("Checking Shipping availability Customer Number" + orderRequestDTO.getCustomerId());
        ShippingCompany company = shippingCompanyRepository.findByName(orderRequestDTO.getShippingCompany());
        if (company == null) {
            System.out.println("Company is null");
            rabbitTemplate.convertAndSend("OrderFailedQueue",new OrderFailedEvent(orderRequestDTO.getId(),"Shipping Company Not Found",orderRequestDTO.getItems(),orderRequestDTO.getItemsTotalPrice()));
            rabbitTemplate.convertAndSend("ShippingFailure",new OrderFailedEvent(orderRequestDTO.getId(),"Shipping Company Not Found",orderRequestDTO.getItems(),orderRequestDTO.getItemsTotalPrice()));
            return;
        }
        boolean locationCovered = company.getRegions().stream()
                .anyMatch(region -> region.equalsIgnoreCase(orderRequestDTO.getShippingLocation()));
        if (!locationCovered) {
            System.out.println("Location Not Covered");
            sendLog("Shipping.Error"," Location Not Covered for Order "+orderRequestDTO.getId());
          rabbitTemplate.convertAndSend("OrderFailedQueue",new OrderFailedEvent(orderRequestDTO.getId(),"Location Not Covered by Shipping Company",orderRequestDTO.getItems(),orderRequestDTO.getItemsTotalPrice()));
          rabbitTemplate.convertAndSend("ShippingFailure",new OrderFailedEvent(orderRequestDTO.getId(),"Location Not Covered by Shipping Company",orderRequestDTO.getItems(),orderRequestDTO.getItemsTotalPrice()));
          return;
        }
        double shippingFees = company.getShipping_fees();
        double finalTotalPrice = orderRequestDTO.getItemsTotalPrice() + shippingFees;
        orderRequestDTO.setItemsTotalPrice(finalTotalPrice);
        System.out.println("Sending to OrderPaymentQueue");
        sendLog("Shipping_Info","Shipping Confirmed for order "+orderRequestDTO.getId());
        rabbitTemplate.convertAndSend("OrderPaymentQueue",orderRequestDTO);


    }
    private void sendLog(String routingKey, String message) {
        LogMessage logMessage = new LogMessage(routingKey, message);
        rabbitTemplate.convertAndSend("log.exchange", routingKey, logMessage);
        System.out.println("[LOG SENT] " + routingKey + ": " + message);
    }

}
