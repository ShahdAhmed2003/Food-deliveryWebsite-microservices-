package com.Food_delievryApp.ShippingService;

import com.Food_delievryApp.ShippingService.dto.OrderRequestDTO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShippingCompanyRepository extends JpaRepository<ShippingCompany,Long> {
    boolean existsByName(String name);

    ShippingCompany findByName(String name);

}
