package com.Food_delievryApp.PaymentService.dto;

import java.util.List;

public class OrderFailedEvent {

        private Long id;
        private String reason;
        private List<OrderItemDTO> items;
        private double price;

        // Constructor, getters, and setters
        public OrderFailedEvent(Long id, String reason, List<OrderItemDTO> items, double price) {
            this.id = id;
            this.reason = reason;
            this.items = items;
            this.price=price;
        }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setReason(String reason) {
            this.reason = reason;
        }

        public void setItems(List<OrderItemDTO> items) {
            this.items = items;
        }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public String getReason() {
            return reason;
        }

        public List<OrderItemDTO> getItems() {
            return items;
        }
}
