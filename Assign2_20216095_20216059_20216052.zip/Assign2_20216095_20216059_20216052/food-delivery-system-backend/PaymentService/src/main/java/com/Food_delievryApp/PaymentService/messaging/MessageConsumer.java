package com.Food_delievryApp.PaymentService.messaging;

import com.Food_delievryApp.PaymentService.dto.LogMessage;
import com.Food_delievryApp.PaymentService.dto.OrderFailedEvent;
import com.Food_delievryApp.PaymentService.dto.OrderRequestDTO;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class MessageConsumer {

    private RabbitTemplate rabbitTemplate;

    public MessageConsumer(RabbitTemplate rabbitTemplate) {

        this.rabbitTemplate = rabbitTemplate;
    }

    @RabbitListener(queues = "OrderPaymentQueue")
    public void consumeMessage(OrderRequestDTO orderRequestDTO) {
        System.out.println("Checking Payment minimum charge for order Number " + orderRequestDTO.getId());
        if(!(orderRequestDTO.getItemsTotalPrice()>=50.0))
        {
            rabbitTemplate.convertAndSend("PaymentFailure",new OrderFailedEvent(orderRequestDTO.getId(),"Payment Rejected: Order total is below the minimum charge of 50.0 EGP.",orderRequestDTO.getItems(),orderRequestDTO.getItemsTotalPrice()));
            System.out.println("Rejected");
            sendLog("Payment.Error", "Order total is below the minimum charge of 50.0 EGP for orderId: " + orderRequestDTO.getId());
            rabbitTemplate.convertAndSend("OrderFailedQueue",new OrderFailedEvent(orderRequestDTO.getId(),"Payment Rejected: Order total is below the minimum charge of 50.0 EGP.",orderRequestDTO.getItems(),orderRequestDTO.getItemsTotalPrice()));
            rabbitTemplate.convertAndSend("payments.exchange",
                    "PaymentFailed",new OrderFailedEvent(orderRequestDTO.getId(),"Payment Rejected: Order total is below the minimum charge of 50.0 EGP.",orderRequestDTO.getItems(),orderRequestDTO.getItemsTotalPrice()));//bonus
            return;
        }
        System.out.println("Confirmed");
        rabbitTemplate.convertAndSend("OrderConfirmedQueue",orderRequestDTO);
        sendLog("Payment_Info", "Payment Confirmed for orderId: " + orderRequestDTO.getId());
    }
    private void sendLog(String routingKey, String message) {
        LogMessage logMessage = new LogMessage(routingKey, message);
        rabbitTemplate.convertAndSend("log.exchange", routingKey, logMessage);
        System.out.println("[LOG SENT] " + routingKey + ": " + message);
    }
}
