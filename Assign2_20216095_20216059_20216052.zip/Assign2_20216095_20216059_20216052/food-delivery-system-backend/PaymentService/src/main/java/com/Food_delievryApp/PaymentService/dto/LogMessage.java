package com.Food_delievryApp.PaymentService.dto;

public class LogMessage {
    private String routingKey;
    private String message;

    // Constructor
    public LogMessage(String routingKey, String message) {
        this.routingKey = routingKey;
        this.message = message;
    }

    // Getters and Setters
    public String getRoutingKey() {
        return routingKey;
    }

    public void setRoutingKey(String routingKey) {
        this.routingKey = routingKey;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

